

I set out to create my own personal webpage that showcases my portfolio, skills, and overall information about me. I also created a section where someone on the website can easily get into contact with me.

VIDEO: https://youtu.be/3h0NLgLls9Y

Flask: Crucial for creating web platforms.
Flask-Mail: Used to create the contact form to take users email as input and send an email insde the web applications.

pip install Flask
pip install Flask-mail


Python Component (Backend)
app.py: The main application file containing routes to different html and backend for flask mail

Templates (Frontend):
 Located in the templates directory, includes index.html, layout.html, contact_me.html, etc for rendering the homepage, contact form, and each individual html.


Static Files:
CSS
- Main place for applying designs that appear often throughout the webpage
Image files are stored in the static directory.

Route Design
Homepage Route (/)
Purpose: Displays the main landing page.
Implementation: Renders index.html.

Layout Route(/layout.html)
Purpose: Creates the general layout of the webpage so that I can use Jinja to easily and efficiently apply it to each embedded webpage
Implementation: Gaining familiarity with HTML language which bootstrap and CSS framework with specific code to design unique and well thought out webpages

All other Routes(/rowing.html, /projects.html, about_me.html, classes.html)
Purpose: Creating a good looking site to convey viewers who I am
Implementation: Continuing to improve dexterity with HTML and its frameworks

Contact Form Route (/contact_me.html)
Purpose: Provides a form for users to send a message to me via their email
Implementation:
GET Request: Renders contact_me.html form.
POST Request: Processes form submission, sends an email using Flask-Mail.
Email Handling
Flask-Mail Configuration: Configured in config.py to interact with the SMTP server. This setup makes sure that form submissions are sent to the specified email address.
Message Creation: The Message object in Flask-Mail is used to format and send emails, with details like sender, recipients, and the message body.
Design Decisions
Flask-Mail:
Email Functionality: Used Flask-Mail for simplicity and reliability in sending emails directly from the application.

Future Improvments
Improve Security: Avoid any hardcoding of passwords and make sure the application is secure

I OMMITED ALL OF THE PHOTOS IN ORDER TO BE ABLE TO SUBMIT VIA GRADESCOPE

from flask import Flask, render_template, request
from flask_mail import Mail, Message

app = Flask(__name__)


app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'leombessler@gmail.com'
app.config['MAIL_PASSWORD'] = 'slmm imni dzff qbah'

mail = Mail(app)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/contact_me.html", methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        email = request.form['email']
        message = request.form['message']

        msg = Message("New Contact Form Submission",
                      sender=email,
                      recipients=['leombessler@gmail.com'])
        msg.body = f"Mail from {email}:\n{message}"
        mail.send(msg)

    return render_template("contact_me.html")

@app.route("/projects.html")
def projects():
    return render_template("projects.html")

@app.route("/classes.html")
def classes():
    return render_template("classes.html")

@app.route("/rowing.html")
def rowing():
    return render_template("rowing.html")

@app.route("/about_me.html")
def about_me():
    return render_template("about_me.html")

if __name__ == "__main__":
    app.run(debug=True)
